package com.portfolio.ArgProg.repository;

import com.portfolio.ArgProg.models.SkillsB;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SkillsBRepo extends JpaRepository<SkillsB, Long> {

}
