package com.portfolio.ArgProg.repository;

import com.portfolio.ArgProg.models.Proyectos;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProyectosRepo extends JpaRepository<Proyectos,Long> {

}
