package com.portfolio.ArgProg.repository;

import com.portfolio.ArgProg.models.Experiencia;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ExperienciaRepo extends JpaRepository<Experiencia, Long> {

}
