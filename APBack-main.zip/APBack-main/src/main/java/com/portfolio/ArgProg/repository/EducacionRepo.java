package com.portfolio.ArgProg.repository;

import com.portfolio.ArgProg.models.Educacion;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EducacionRepo extends JpaRepository<Educacion, Long> {

}
