package com.portfolio.ArgProg.repository;

import com.portfolio.ArgProg.models.SkillsS;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SkillsSRepo extends JpaRepository<SkillsS, Long> {

}
